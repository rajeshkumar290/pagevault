# PageVault — campus textbook exchange

Education / Digital Library project.

## Contents
- `static/` — Modules 1–2: library home, category grid, book detail. Plain HTML + CSS (Grid, mobile-first media queries). Open `static/index.html` in a browser.
- `client/` — Modules 3–4: React 18 + React Router + Context + Vite.

## Run the React app
```
cd client
npm install
npm run dev
```
Open the printed URL (usually http://localhost:5173).

## Demo flow (from the brief)
1. Signed in as **Asha**, open *List a book*, add "Operating System Concepts" with course `CS301` (or use the seeded copy owned by Asha).
2. Switch to **Ravi** (top bar), search `CS301`, open the book, click *Request borrow*. Badge becomes **Reserved**.
3. Switch to **Asha**, open *My exchanges*, click *Approve*. Badge becomes **Borrowed**.
4. Switch to **Ravi**: 7-day countdown is shown. Click *+1 day* several times to reach the "due soon" and "overdue" banners. Click *Turn on browser alerts* for desktop notifications.
5. Ravi clicks *Mark returned*; the book is Available again.

## Where each requirement lives
| Feature | File |
|---|---|
| Listing + validation + course tagging | `src/pages/ListBook.jsx` |
| Search by course/title/department, status filter | `src/pages/Catalog.jsx` |
| Request → Approved → Returned workflow, atomic double-borrow guard | `src/context/LibraryContext.jsx` |
| Availability badge (derived from requests) | `src/components/StatusBadge.jsx` |
| Due dates, countdown, banners, browser alerts (no cron) | `src/utils/due.js`, `Banner.jsx`, context |
| My exchanges dashboard | `src/pages/MyExchanges.jsx` |
| SVG fallback cover | `src/components/Cover.jsx` |
| Favourites | `src/pages/Favourites.jsx` |
| Open Library search (useEffect + fetch) | `src/pages/Discover.jsx` |
| 35 seed books | `src/data/books.js` |

## Notes
- Data is stored in `localStorage` (no backend needed). To follow the brief's Express + SQLite stack, replace the functions in `LibraryContext.jsx` with `fetch` calls.
- ISBNs in the seed data are used only for cover lookup; missing covers fall back to an SVG.
- Not included yet (stretch): barcode scanner, ratings, chat, wishlist alerts.
