import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Banner from './components/Banner'
import Home from './pages/Home'
import Catalog from './pages/Catalog'
import BookDetail from './pages/BookDetail'
import ListBook from './pages/ListBook'
import MyExchanges from './pages/MyExchanges'
import Favourites from './pages/Favourites'
import Discover from './pages/Discover'

export default function App() {
  return (
    <>
      <Navbar />
      <Banner />
      <main className="wrap">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/catalog" element={<Catalog />} />
          <Route path="/books/:id" element={<BookDetail />} />
          <Route path="/list" element={<ListBook />} />
          <Route path="/exchanges" element={<MyExchanges />} />
          <Route path="/favourites" element={<Favourites />} />
          <Route path="/discover" element={<Discover />} />
          <Route path="*" element={<p>Page not found.</p>} />
        </Routes>
      </main>
    </>
  )
}
