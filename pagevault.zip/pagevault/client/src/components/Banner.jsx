import { Link } from 'react-router-dom'
import { useLibrary } from '../context/LibraryContext'
import { countdown } from '../utils/due'

export default function Banner() {
  const { reminders, bookById, now } = useLibrary()
  const askPermission = () => typeof Notification !== 'undefined' && Notification.requestPermission()
  const canAsk = typeof Notification !== 'undefined' && Notification.permission === 'default'
  if (!reminders.length && !canAsk) return null
  return (
    <div className="banners" role="status">
      {reminders.map(({ req, level }) => (
        <div key={req.id} className={`banner ${level}`}>
          <strong>{level === 'overdue' ? 'Overdue:' : 'Due soon:'}</strong>{' '}
          {bookById(req.bookId)?.title} — {countdown(req.dueAt, now)}.{' '}
          <Link to="/exchanges">Go to My exchanges</Link>
        </div>
      ))}
      {canAsk && <div className="banner info">Want reminders when a return date is close? <button onClick={askPermission}>Turn on browser alerts</button></div>}
    </div>
  )
}
