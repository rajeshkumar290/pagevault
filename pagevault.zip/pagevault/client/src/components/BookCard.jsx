import { Link } from 'react-router-dom'
import Cover from './Cover'
import StatusBadge from './StatusBadge'
import { useLibrary } from '../context/LibraryContext'

export default function BookCard({ book }) {
  const { statusOf, favs, toggleFav } = useLibrary()
  const status = book.available ? statusOf(book.id) : 'Reserved'
  const fav = favs.includes(book.id)
  return (
    <article className="book-card">
      <Link to={`/books/${book.id}`}><Cover book={book} /></Link>
      <div className="book-meta">
        <StatusBadge status={status} />
        <h3><Link to={`/books/${book.id}`}>{book.title}</Link></h3>
        <p className="muted">{book.author} · {book.edition} ed.</p>
        <p className="course">{book.course}</p>
      </div>
      <button className={`fav ${fav ? 'on' : ''}`} aria-pressed={fav} aria-label={fav ? 'Remove from favourites' : 'Add to favourites'} onClick={() => toggleFav(book.id)}>{fav ? '★' : '☆'}</button>
    </article>
  )
}
