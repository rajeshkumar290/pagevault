import { useState } from 'react'

// Open Library cover by ISBN; falls back to an SVG with the title and course code.
export default function Cover({ book }) {
  const [failed, setFailed] = useState(!book.isbn)
  if (!failed) {
    return <img className="cover" loading="lazy" alt={`Cover of ${book.title}`}
      src={`https://covers.openlibrary.org/b/isbn/${book.isbn}-M.jpg?default=false`} onError={() => setFailed(true)} />
  }
  const words = book.title.split(' '), lines = []
  let cur = ''
  words.forEach(w => { if ((cur + ' ' + w).trim().length > 16) { lines.push(cur); cur = w } else cur = (cur + ' ' + w).trim() })
  lines.push(cur)
  const hue = [...book.course].reduce((a, c) => a + c.charCodeAt(0), 0) % 360
  return (
    <svg className="cover" viewBox="0 0 150 200" role="img" aria-label={`${book.title}, ${book.course}`}>
      <rect width="150" height="200" fill={`hsl(${hue} 35% 26%)`} />
      <rect x="10" width="4" height="200" fill="rgba(255,255,255,.25)" />
      {lines.slice(0, 5).map((l, i) => <text key={i} x="24" y={48 + i * 18} fill="#F3F5F0" fontSize="14" fontWeight="700" fontFamily="sans-serif">{l}</text>)}
      <text x="24" y="182" fill="#E8C675" fontSize="13" fontFamily="sans-serif">{book.course}</text>
    </svg>
  )
}
