import { NavLink, Link } from 'react-router-dom'
import { useLibrary } from '../context/LibraryContext'

export default function Navbar() {
  const { user, users, switchUser, skipDays, dayOffset, reset } = useLibrary()
  return (
    <header className="site">
      <div className="wrap bar">
        <Link to="/" className="brand">PageVault</Link>
        <nav>
          <NavLink to="/catalog">Catalog</NavLink>
          <NavLink to="/discover">Discover</NavLink>
          <NavLink to="/list">List a book</NavLink>
          <NavLink to="/exchanges">My exchanges</NavLink>
          <NavLink to="/favourites">Favourites</NavLink>
        </nav>
        <div className="demo">
          <label>Signed in as{' '}
            <select value={user.id} onChange={e => switchUser(e.target.value)}>
              {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
          </label>
          <button onClick={() => skipDays(1)} title="Demo: move the clock forward one day">+1 day{dayOffset ? ` (${dayOffset})` : ''}</button>
          <button onClick={() => { if (confirm('Reset all demo data?')) reset() }}>Reset</button>
        </div>
      </div>
    </header>
  )
}
