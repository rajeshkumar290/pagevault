import { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { SEED_BOOKS, USERS } from '../data/books'
import { DAY, LOAN_DAYS, level } from '../utils/due'

const KEY = 'pagevault:v1'
const fresh = () => ({ books: SEED_BOOKS, requests: [], favs: {}, userId: 'u1', dayOffset: 0 })
const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || fresh() } catch { return fresh() } }

const Ctx = createContext(null)
export const useLibrary = () => useContext(Ctx)

export function LibraryProvider({ children }) {
  const [state, setState] = useState(load)
  const [tick, setTick] = useState(Date.now())
  const notified = useRef(new Set())

  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(state)) } catch {} }, [state])
  useEffect(() => { const t = setInterval(() => setTick(Date.now()), 30000); return () => clearInterval(t) }, [])

  // "Now" is real time plus a demo offset so overdue states can be shown without waiting a week.
  const now = tick + state.dayOffset * DAY
  const user = USERS.find(u => u.id === state.userId)
  const update = fn => setState(s => fn(s))
  const stamp = s => Date.now() + s.dayOffset * DAY

  // Status is derived from requests, so a badge can never go stale.
  const statusOf = bookId => {
    const open = state.requests.find(r => r.bookId === bookId && (r.state === 'Pending' || r.state === 'Approved'))
    if (!open) return 'Available'
    return open.state === 'Pending' ? 'Reserved' : 'Borrowed'
  }
  const bookById = id => state.books.find(b => b.id === id)

  const api = {
    addBook: book => update(s => ({ ...s, books: [{ ...book, id: 'b' + Date.now(), ownerId: s.userId, available: true }, ...s.books] })),
    toggleAvailable: id => update(s => ({ ...s, books: s.books.map(b => b.id === id ? { ...b, available: !b.available } : b) })),
    // Atomic: the check and the insert happen in one state update, so a second request on the same book is refused.
    requestBorrow: bookId => {
      let result = 'ok'
      update(s => {
        const book = s.books.find(b => b.id === bookId)
        const busy = s.requests.some(r => r.bookId === bookId && (r.state === 'Pending' || r.state === 'Approved'))
        if (!book || !book.available || busy) { result = 'unavailable'; return s }
        if (book.ownerId === s.userId) { result = 'own'; return s }
        const req = { id: 'r' + Date.now(), bookId, borrowerId: s.userId, lenderId: book.ownerId, state: 'Pending', requestedAt: stamp(s) }
        return { ...s, requests: [req, ...s.requests] }
      })
      return result
    },
    approve: id => update(s => ({ ...s, requests: s.requests.map(r => r.id === id ? { ...r, state: 'Approved', approvedAt: stamp(s), dueAt: stamp(s) + LOAN_DAYS * DAY } : r) })),
    reject: id => update(s => ({ ...s, requests: s.requests.map(r => r.id === id ? { ...r, state: 'Rejected' } : r) })),
    markReturned: id => update(s => ({ ...s, requests: s.requests.map(r => r.id === id ? { ...r, state: 'Returned', returnedAt: stamp(s) } : r) })),
    toggleFav: id => update(s => {
      const mine = new Set(s.favs[s.userId] || []); mine.has(id) ? mine.delete(id) : mine.add(id)
      return { ...s, favs: { ...s.favs, [s.userId]: [...mine] } }
    }),
    switchUser: userId => update(s => ({ ...s, userId })),
    skipDays: n => update(s => ({ ...s, dayOffset: s.dayOffset + n })),
    reset: () => setState(fresh()),
  }

  const favs = state.favs[state.userId] || []
  const myBorrowed = state.requests.filter(r => r.borrowerId === state.userId)
  const myLent = state.requests.filter(r => r.lenderId === state.userId)

  // Reminders are computed on render from dueAt, so no server cron is needed.
  const reminders = useMemo(() => myBorrowed
    .filter(r => r.state === 'Approved')
    .map(r => ({ req: r, level: level(r.dueAt, now) }))
    .filter(x => x.level !== 'ok'), [state.requests, state.userId, now])

  useEffect(() => {
    reminders.forEach(({ req, level: lv }) => {
      const k = req.id + lv
      if (notified.current.has(k)) return
      notified.current.add(k)
      if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return
      const b = state.books.find(b => b.id === req.bookId)
      new Notification(lv === 'overdue' ? 'Book overdue' : 'Book due soon', { body: `"${b?.title}" ${lv === 'overdue' ? 'is past its return date.' : 'is due back within 2 days.'}` })
    })
  }, [reminders])

  const value = { ...state, user, users: USERS, now, favs, myBorrowed, myLent, reminders, statusOf, bookById, ...api }
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}
