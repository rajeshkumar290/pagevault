// 35 seed textbooks: [title, author, edition, isbn, course, department]
// Covers load from Open Library by ISBN; the SVG fallback is used if they fail.
const rows = [
['Operating System Concepts','Silberschatz, Galvin, Gagne','10th','9781119800361','CS301','Computer Science'],
['Introduction to Algorithms','Cormen, Leiserson, Rivest, Stein','3rd','9780262033848','CS201','Computer Science'],
['Computer Networks','Andrew S. Tanenbaum','5th','9780132126953','CS305','Computer Science'],
['Computer Networking: A Top-Down Approach','Kurose, Ross','7th','9780133594140','CS305','Computer Science'],
['Database System Concepts','Silberschatz, Korth, Sudarshan','7th','9780078022159','CS302','Computer Science'],
['Artificial Intelligence: A Modern Approach','Russell, Norvig','4th','9780134610993','CS401','Computer Science'],
['Compilers: Principles, Techniques, and Tools','Aho, Lam, Sethi, Ullman','2nd','9780321486813','CS402','Computer Science'],
['Computer Organization and Design','Patterson, Hennessy','5th','9780124077263','CS204','Computer Science'],
['Clean Code','Robert C. Martin','1st','9780132350884','CS210','Computer Science'],
['Microelectronic Circuits','Sedra, Smith','7th','9780199339136','EE210','Electrical Engineering'],
['Signals and Systems','Oppenheim, Willsky','2nd','9780138147570','EE301','Electrical Engineering'],
['Digital Design','M. Morris Mano','5th','9780132774208','EE204','Electrical Engineering'],
['Engineering Circuit Analysis','Hayt, Kemmerly, Durbin','9th','9780073545516','EE101','Electrical Engineering'],
['Electric Machinery Fundamentals','Stephen J. Chapman','5th','9780073529547','EE305','Electrical Engineering'],
['Power System Analysis','Grainger, Stevenson','1st','9780070612938','EE402','Electrical Engineering'],
['Fundamentals of Thermodynamics','Borgnakke, Sonntag','8th','9780470041925','ME204','Mechanical Engineering'],
['Fluid Mechanics','Frank M. White','8th','9780073398273','ME301','Mechanical Engineering'],
['Mechanics of Materials','Hibbeler','10th','9780134319650','ME202','Mechanical Engineering'],
["Shigley's Mechanical Engineering Design",'Budynas, Nisbett','10th','9780073398204','ME305','Mechanical Engineering'],
['Heat and Mass Transfer','Cengel, Ghajar','5th','9780073398181','ME303','Mechanical Engineering'],
['Advanced Engineering Mathematics','Erwin Kreyszig','10th','9780470458365','MA201','Mathematics'],
['Calculus: Early Transcendentals','James Stewart','8th','9781285741550','MA101','Mathematics'],
['Linear Algebra and Its Applications','David C. Lay','5th','9780321982384','MA102','Mathematics'],
['Discrete Mathematics and Its Applications','Kenneth Rosen','7th','9780073383095','MA203','Mathematics'],
['Probability and Statistics for Engineers','Walpole, Myers','9th','9780321629111','MA204','Mathematics'],
['Fundamentals of Physics','Halliday, Resnick, Walker','10th','9781118230718','PH102','Physics'],
['University Physics','Young, Freedman','14th','9780321973610','PH101','Physics'],
['Introduction to Electrodynamics','David J. Griffiths','4th','9781108420419','PH201','Physics'],
['Introduction to Quantum Mechanics','David J. Griffiths','2nd','9781107179868','PH301','Physics'],
['Concepts of Modern Physics','Arthur Beiser','6th','9780072448481','PH202','Physics'],
['Chemistry: The Central Science','Brown, LeMay, Bursten','14th','9780134414232','CH101','Chemistry'],
['Organic Chemistry','Clayden, Greeves, Warren','2nd','9780199270293','CH201','Chemistry'],
['Physical Chemistry','Peter Atkins','10th','9780199697403','CH202','Chemistry'],
['Inorganic Chemistry','Miessler, Fischer, Tarr','5th','9780321811059','CH301','Chemistry'],
['Principles of Instrumental Analysis','Skoog, Holler, Crouch','7th','9781305577213','CH302','Chemistry'],
]
export const DEPARTMENTS = [...new Set(rows.map(r => r[5]))]
export const USERS = [
  { id: 'u1', name: 'Asha', dept: 'Computer Science', contact: 'asha@campus.edu' },
  { id: 'u2', name: 'Ravi', dept: 'Electrical Engineering', contact: 'ravi@campus.edu' },
  { id: 'u3', name: 'Meera', dept: 'Mechanical Engineering', contact: 'meera@campus.edu' },
]
const conditions = ['Like new', 'Good', 'Fair']
export const SEED_BOOKS = rows.map(([title, author, edition, isbn, course, dept], i) => ({
  id: 'b' + (i + 1), title, author, edition, isbn, course, dept,
  condition: conditions[i % 3], available: true, ownerId: USERS[i % 3].id,
}))
