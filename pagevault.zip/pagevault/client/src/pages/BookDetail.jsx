import { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useLibrary } from '../context/LibraryContext'
import Cover from '../components/Cover'
import StatusBadge from '../components/StatusBadge'

export default function BookDetail() {
  const { id } = useParams()
  const { bookById, statusOf, requestBorrow, user, users, favs, toggleFav } = useLibrary()
  const [msg, setMsg] = useState('')
  const book = bookById(id)
  if (!book) return <p className="empty">This book isn't in the catalog. <Link to="/catalog">Back to catalog</Link></p>
  const owner = users.find(u => u.id === book.ownerId)
  const status = book.available ? statusOf(book.id) : 'Reserved'
  const isOwner = owner?.id === user.id

  const request = () => {
    const r = requestBorrow(book.id)
    setMsg(r === 'ok' ? `Request sent to ${owner?.name}. The book is now Reserved.` : r === 'own' ? 'This is your own book.' : 'Someone else already requested this book.')
  }

  return (
    <div className="detail">
      <Cover book={book} />
      <div>
        <StatusBadge status={status} />
        <h1>{book.title}</h1>
        <p>{book.author}</p>
        <dl>
          <dt>Edition</dt><dd>{book.edition}</dd>
          <dt>Course</dt><dd>{book.course} · {book.dept}</dd>
          <dt>Condition</dt><dd>{book.condition}</dd>
          <dt>Owner</dt><dd>{owner ? `${owner.name} (${owner.contact})` : 'Unknown'}</dd>
          <dt>Loan period</dt><dd>7 days</dd>
        </dl>
        <div className="row">
          <button className="btn" disabled={status !== 'Available' || isOwner} onClick={request}>
            {isOwner ? 'Your book' : status === 'Available' ? 'Request borrow' : `Currently ${status.toLowerCase()}`}
          </button>
          <button className="btn ghost" onClick={() => toggleFav(book.id)}>{favs.includes(book.id) ? '★ Saved' : '☆ Save'}</button>
        </div>
        {msg && <p role="status" className="note">{msg} <Link to="/exchanges">Open My exchanges</Link></p>}
      </div>
    </div>
  )
}
