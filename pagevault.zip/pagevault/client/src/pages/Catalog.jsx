import { useSearchParams, Link } from 'react-router-dom'
import { useLibrary } from '../context/LibraryContext'
import BookCard from '../components/BookCard'
import { DEPARTMENTS } from '../data/books'

export default function Catalog() {
  const { books, statusOf } = useLibrary()
  const [params, setParams] = useSearchParams()
  const q = params.get('q') || '', dept = params.get('dept') || '', status = params.get('status') || ''
  const set = (k, v) => { const p = new URLSearchParams(params); v ? p.set(k, v) : p.delete(k); setParams(p, { replace: true }) }

  const needle = q.trim().toLowerCase()
  const results = books.filter(b => {
    const text = `${b.title} ${b.author} ${b.course} ${b.dept}`.toLowerCase()
    return (!needle || text.includes(needle)) && (!dept || b.dept === dept) &&
      (!status || (b.available ? statusOf(b.id) : 'Reserved') === status)
  })

  return (
    <>
      <h1>Catalog</h1>
      <div className="filters">
        <input type="search" value={q} onChange={e => set('q', e.target.value)} placeholder="Course code, title or department (try CS301)" aria-label="Search books" />
        <select value={dept} onChange={e => set('dept', e.target.value)} aria-label="Department">
          <option value="">All departments</option>
          {DEPARTMENTS.map(d => <option key={d}>{d}</option>)}
        </select>
        <select value={status} onChange={e => set('status', e.target.value)} aria-label="Availability">
          <option value="">Any status</option>
          <option>Available</option><option>Reserved</option><option>Borrowed</option>
        </select>
      </div>
      <p className="muted">{results.length} {results.length === 1 ? 'book' : 'books'}</p>
      {results.length ? <div className="grid">{results.map(b => <BookCard key={b.id} book={b} />)}</div>
        : <p className="empty">No books match. Check the course code, or clear a filter. You can also <Link to="/list">list a book</Link> for others.</p>}
    </>
  )
}
