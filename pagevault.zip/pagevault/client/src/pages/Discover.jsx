import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'

// Book search through the Open Library API (Module 3: useEffect + fetch).
export default function Discover() {
  const [q, setQ] = useState('')
  const [docs, setDocs] = useState([])
  const [state, setState] = useState('idle')
  const nav = useNavigate()

  useEffect(() => {
    if (q.trim().length < 3) { setDocs([]); setState('idle'); return }
    const ctl = new AbortController()
    const t = setTimeout(async () => {
      setState('loading')
      try {
        const res = await fetch(`https://openlibrary.org/search.json?q=${encodeURIComponent(q)}&limit=12&fields=title,author_name,isbn,edition_count,first_publish_year`, { signal: ctl.signal })
        if (!res.ok) throw new Error()
        setDocs((await res.json()).docs); setState('done')
      } catch (e) { if (e.name !== 'AbortError') setState('error') }
    }, 400)
    return () => { clearTimeout(t); ctl.abort() }
  }, [q])

  return (
    <>
      <h1>Discover books</h1>
      <p className="muted">Search Open Library, then list your copy with the details filled in.</p>
      <input className="wide" type="search" value={q} onChange={e => setQ(e.target.value)} placeholder="Title or author, at least 3 letters" aria-label="Search Open Library" />
      {state === 'loading' && <p role="status">Searching…</p>}
      {state === 'error' && <p className="error" role="alert">Couldn't reach Open Library. Check your connection and try again.</p>}
      {state === 'done' && !docs.length && <p className="empty">No results for "{q}".</p>}
      <ul className="results">
        {docs.map((d, i) => (
          <li key={i} className="row-card">
            <span><strong>{d.title}</strong><br /><span className="muted">{(d.author_name || ['Unknown author']).slice(0, 2).join(', ')}{d.first_publish_year ? ` · ${d.first_publish_year}` : ''}</span></span>
            <button className="btn sm" onClick={() => nav('/list', { state: { title: d.title, author: (d.author_name || [''])[0], isbn: (d.isbn || [''])[0], edition: '1st' } })}>List my copy</button>
          </li>
        ))}
      </ul>
    </>
  )
}
