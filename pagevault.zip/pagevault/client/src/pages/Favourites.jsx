import { Link } from 'react-router-dom'
import { useLibrary } from '../context/LibraryContext'
import BookCard from '../components/BookCard'

export default function Favourites() {
  const { books, favs } = useLibrary()
  const list = books.filter(b => favs.includes(b.id))
  return (
    <>
      <h1>Favourites</h1>
      {list.length ? <div className="grid">{list.map(b => <BookCard key={b.id} book={b} />)}</div>
        : <p className="empty">Tap the star on any book to save it here. <Link to="/catalog">Browse the catalog</Link>.</p>}
    </>
  )
}
