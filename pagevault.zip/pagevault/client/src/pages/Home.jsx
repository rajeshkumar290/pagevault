import { Link } from 'react-router-dom'
import { useLibrary } from '../context/LibraryContext'
import BookCard from '../components/BookCard'
import { DEPARTMENTS } from '../data/books'

const SPINES = [['CS201', 110, '#2F7F73'], ['CS301', 150, '#B07D1E'], ['MA101', 95, '#B5372B'], ['PH102', 135, '#5B6FA6'], ['EE210', 120, '#7A5C8E'], ['ME204', 160, '#2F7F73'], ['CH101', 105, '#B07D1E'], ['CS305', 140, '#B5372B']]

export default function Home() {
  const { books } = useLibrary()
  return (
    <>
      <section className="hero">
        <h1>Borrow the textbook your course needs.</h1>
        <p>Search by course code, ask a classmate for their copy, and get a reminder before it's due back.</p>
        <Link className="btn" to="/catalog">Find a book</Link>
        <div className="shelf" aria-hidden="true">
          {SPINES.map(([c, h, bg]) => <span key={c} className="spine" style={{ height: h, background: bg }}>{c}</span>)}
        </div>
      </section>
      <section>
        <h2>Departments</h2>
        <div className="chips">
          {DEPARTMENTS.map(d => <Link key={d} className="chip" to={`/catalog?dept=${encodeURIComponent(d)}`}>{d}</Link>)}
        </div>
      </section>
      <section>
        <h2>Recently listed</h2>
        <div className="grid">{books.slice(0, 6).map(b => <BookCard key={b.id} book={b} />)}</div>
      </section>
    </>
  )
}
