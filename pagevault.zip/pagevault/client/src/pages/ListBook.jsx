import { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useLibrary } from '../context/LibraryContext'
import { DEPARTMENTS } from '../data/books'

const COURSE = /^[A-Z]{2,4}\d{3}$/
export default function ListBook() {
  const { addBook } = useLibrary()
  const nav = useNavigate()
  const prefill = useLocation().state || {}
  const [f, setF] = useState({ title: '', author: '', edition: '', isbn: '', course: '', dept: DEPARTMENTS[0], condition: 'Good', ...prefill })
  const [errors, setErrors] = useState({})
  const on = k => e => setF({ ...f, [k]: k === 'course' ? e.target.value.toUpperCase() : e.target.value })

  const submit = e => {
    e.preventDefault()
    const er = {}
    if (!f.title.trim()) er.title = 'Enter the book title.'
    if (!f.author.trim()) er.author = 'Enter the author.'
    if (!f.edition.trim()) er.edition = 'Enter the edition, for example 3rd.'
    if (!COURSE.test(f.course.trim())) er.course = 'Use a course code like CS201 (letters then 3 digits).'
    setErrors(er)
    if (Object.keys(er).length) return
    addBook({ ...f, title: f.title.trim(), author: f.author.trim(), course: f.course.trim() })
    nav('/catalog?q=' + encodeURIComponent(f.course.trim()))
  }

  const Field = ({ k, label, children }) => (
    <label className="field">{label}{children}{errors[k] && <span className="error" role="alert">{errors[k]}</span>}</label>
  )
  return (
    <form onSubmit={submit} noValidate className="form">
      <h1>List a book</h1>
      <Field k="title" label="Title"><input value={f.title} onChange={on('title')} /></Field>
      <Field k="author" label="Author"><input value={f.author} onChange={on('author')} /></Field>
      <div className="two">
        <Field k="edition" label="Edition"><input value={f.edition} onChange={on('edition')} /></Field>
        <Field k="isbn" label="ISBN (optional, shows the cover)"><input value={f.isbn} onChange={on('isbn')} /></Field>
      </div>
      <div className="two">
        <Field k="course" label="Course code"><input value={f.course} onChange={on('course')} placeholder="CS201" /></Field>
        <Field k="dept" label="Department"><select value={f.dept} onChange={on('dept')}>{DEPARTMENTS.map(d => <option key={d}>{d}</option>)}</select></Field>
      </div>
      <Field k="condition" label="Condition"><select value={f.condition} onChange={on('condition')}><option>Like new</option><option>Good</option><option>Fair</option></select></Field>
      <button className="btn">List this book</button>
    </form>
  )
}
