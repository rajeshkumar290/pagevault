import { Link } from 'react-router-dom'
import { useLibrary } from '../context/LibraryContext'
import StatusBadge from '../components/StatusBadge'
import { countdown, level } from '../utils/due'

export default function MyExchanges() {
  const { books, user, users, myBorrowed, myLent, bookById, now, approve, reject, markReturned, toggleAvailable, statusOf } = useLibrary()
  const mine = books.filter(b => b.ownerId === user.id)
  const incoming = myLent.filter(r => r.state === 'Pending')
  const lent = myLent.filter(r => r.state === 'Approved')
  const borrowing = myBorrowed.filter(r => r.state === 'Pending' || r.state === 'Approved')
  const history = [...myBorrowed, ...myLent].filter(r => ['Returned', 'Rejected'].includes(r.state))
  const title = r => bookById(r.bookId)?.title

  return (
    <>
      <h1>My exchanges</h1>

      <section>
        <h2>Requests waiting for you</h2>
        {incoming.length ? incoming.map(r => (
          <div className="row-card" key={r.id}>
            <span><strong>{title(r)}</strong> requested by {users.find(u => u.id === r.borrowerId)?.name}</span>
            <span><button className="btn sm" onClick={() => approve(r.id)}>Approve</button> <button className="btn sm ghost" onClick={() => reject(r.id)}>Decline</button></span>
          </div>)) : <p className="empty">No pending requests.</p>}
      </section>

      <section>
        <h2>Books I'm borrowing</h2>
        {borrowing.length ? borrowing.map(r => (
          <div className={`row-card ${r.state === 'Approved' ? level(r.dueAt, now) : ''}`} key={r.id}>
            <span><strong>{title(r)}</strong> <StatusBadge status={r.state === 'Pending' ? 'Reserved' : 'Borrowed'} /></span>
            {r.state === 'Pending' ? <span className="muted">Waiting for the owner to approve</span>
              : <span><span className="timer">{countdown(r.dueAt, now)}</span> <button className="btn sm" onClick={() => markReturned(r.id)}>Mark returned</button></span>}
          </div>)) : <p className="empty">Nothing borrowed. <Link to="/catalog">Find a book</Link>.</p>}
      </section>

      <section>
        <h2>Books I've lent out</h2>
        {lent.length ? lent.map(r => (
          <div className={`row-card ${level(r.dueAt, now)}`} key={r.id}>
            <span><strong>{title(r)}</strong></span><span className="timer">{countdown(r.dueAt, now)}</span>
          </div>)) : <p className="empty">None of your books are out on loan.</p>}
      </section>

      <section>
        <h2>My listed books</h2>
        {mine.length ? mine.map(b => (
          <div className="row-card" key={b.id}>
            <span><Link to={`/books/${b.id}`}>{b.title}</Link> · {b.course} <StatusBadge status={b.available ? statusOf(b.id) : 'Reserved'} /></span>
            <label className="toggle"><input type="checkbox" checked={b.available} onChange={() => toggleAvailable(b.id)} /> Available to borrow</label>
          </div>)) : <p className="empty">You haven't listed a book. <Link to="/list">List one</Link>.</p>}
      </section>

      <section>
        <h2>History</h2>
        {history.length ? history.map(r => <div className="row-card" key={r.id}><span>{title(r)}</span><span className="muted">{r.state}</span></div>)
          : <p className="empty">Returned and declined requests appear here.</p>}
      </section>
    </>
  )
}
