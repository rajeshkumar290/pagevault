export const DAY = 86400000
export const LOAN_DAYS = 7
export function remaining(dueAt, now) { return dueAt - now }
export function level(dueAt, now) {
  const r = remaining(dueAt, now)
  if (r < 0) return 'overdue'
  if (r <= 2 * DAY) return 'soon'
  return 'ok'
}
export function countdown(dueAt, now) {
  const r = Math.abs(remaining(dueAt, now))
  const d = Math.floor(r / DAY), h = Math.floor((r % DAY) / 3600000), m = Math.floor((r % 3600000) / 60000)
  const text = `${d}d ${h}h ${m}m`
  return remaining(dueAt, now) < 0 ? `${text} overdue` : `${text} left`
}
